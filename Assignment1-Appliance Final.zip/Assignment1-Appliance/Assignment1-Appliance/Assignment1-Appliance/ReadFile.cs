﻿using System;
using System.IO;

namespace Assignment1
{
    internal class ReadFile
    {
        static void Main(string[] args)
        {
            string fileName = "C:\\Users\\tpear\\OneDrive\\Documents\\SAIT\\Term 2\\Object-Oriented Programming_C#\\Assignment1-Appliance\\Assignment1-Appliance\\appliances.txt";
            string[] fileLines = File.ReadAllLines(fileName);
            
            foreach(string line in fileLines) 
            {
                Console.WriteLine(line);
                string[] fields = line.Split(',');

            }
        }
    }
}