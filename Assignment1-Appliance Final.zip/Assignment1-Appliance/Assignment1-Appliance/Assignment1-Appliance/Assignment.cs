﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1_Appliance
{
    abstract class Appliance
    {
        string ItemNumber { get; set; }
        string Brand { get; set; }
        int Quantity { get; set; }
        int Wattage { get; set; }
        string Color { get; set; }
        decimal Price { get; set; }

        protected Appliance(string itemNumber, string brand, int quantity, int wattage, string color, decimal price)
        {
            ItemNumber = itemNumber;
            Brand = brand;
            Quantity = quantity;
            Wattage = wattage;
            Color = color;
            Price = price;
        }
    }

    class Refrigerator : Appliance
    {
        public int NumberOfDoors { get; set; }
        public int Height { get; set; }
        public int Width { get; set; }

        public Refrigerator(string itemNumber, string brand, int quantity, int wattage, string color, decimal price, int numberOfDoors, int height, int width)
            : base(itemNumber, brand, quantity, wattage, color, price)
        {
            NumberOfDoors = numberOfDoors;
            Height = height;
            Width = width;
        }
    }

    class Vacuum : Appliance
    {
        public string Grade { get; set; }
        public int BatteryVoltage { get; set; }

        public Vacuum(string itemNumber, string brand, int quantity, int wattage, string color, decimal price, string grade, int batteryVoltage)
            : base(itemNumber, brand, quantity, wattage, color, price)
        {
            Grade = grade;
            BatteryVoltage = batteryVoltage;
        }
    }

    class Microwave : Appliance
    {
        public decimal Capacity { get; set; }
        public char RoomType { get; set; }

        public Microwave(string itemNumber, string brand, int quantity, int wattage, string color, decimal price, decimal capacity, char roomType)
            : base(itemNumber, brand, quantity, wattage, color, price)
        {
            Capacity = capacity;
            RoomType = roomType;
        }
    }

    class Dishwasher : Appliance
    {
        public string Feature { get; set; }
        public string SoundRating { get; set; }

        public Dishwasher(string itemNumber, string brand, int quantity, int wattage, string color, decimal price, string feature, string soundRating)
            : base(itemNumber, brand, quantity, wattage, color, price)
        {
            Feature = feature;
            SoundRating = soundRating;
        }
    }

    
    public static void PurchaseAppliance(List<Appliance> appliances)
    {
        Console.WriteLine("Enter the item number of the appliance you want to purchase:");
        string itemNumber = Console.ReadLines();

        Appliance selectedAppliance = appliances.Find(appliance => appliance.ItemNumber == itemNumber);

        if (selectedAppliance != null)
        {
            if (selectedAppliance.Quantity > 0)
            {
               selectedAppliance.Quantity--;

                Console.WriteLine("Appliance purchased successfully!");
                Console.WriteLine(selectedAppliance.ToString());
            }
            else
            {
                Console.WriteLine("Appliance is currently out of stock.");
            }
        }
        else
        {
            Console.WriteLine("Appliance not found. Please check the item number.");
        }
    }

    public static void FindAppliancesByBrand(List<Appliance> appliances)
    {
        Console.WriteLine("Enter the brand name:");
        string brand = Console.ReadLines();

        List<Appliance> matchingAppliances = appliances.FindAll(appliance =>
            string.Equals(appliance.Brand, brand, StringComparison.OrdinalIgnoreCase));

        if (matchingAppliances.Count > 0)
        {
            Console.WriteLine($"Appliances by brand '{brand}':");
            foreach (Appliance appliance in matchingAppliances)
            {
                Console.WriteLine(appliance.ToString());
            }
        }
        else
        {
            Console.WriteLine("No appliances found for the specified brand.");
        }
    }

    public static void DisplayRandomAppliances(List<Appliance> appliances)
    {
        Console.WriteLine("Enter the number of random appliances to display:");
        int count;
        bool isValidInput = int.TryParse(Console.ReadLine(), out count);

        if (isValidInput && count > 0)
        {
            Random random = new Random();

            Console.WriteLine($"Random Appliances ({count}):");
            for (int i = 0; i < count; i++)
            {
                int randomIndex = random.Next(appliances.Count);
                Appliance randomAppliance = appliances[randomIndex];
                Console.WriteLine(randomAppliance.ToString());
            }
        }
        else
        {
            Console.WriteLine("Invalid input. Please enter a positive number.");
        }
    }

    public static void SaveAppliancesToFile(List<Appliance> appliances)
    {
        using (StreamWriter writer = new StreamWriter("appliances.txt"))
        {
            foreach (Appliance appliance in appliances)
            {
                writer.WriteLine(appliance.ToDataString());
            }
        }

        Console.WriteLine("Appliances successfully saved to file.");
    }

    public static void Main(string[] args)
    {
        Console.WriteLine("Welcome to Modern Appliances!");
        Console.WriteLine("How may we assist you?");
        Console.WriteLine("1 – Check out appliance");
        Console.WriteLine("2 – Find appliances by brand");
        Console.WriteLine("3 – Display appliances by type");
        Console.WriteLine("4 – Produce random appliance list");
        Console.WriteLine("5 – Save & exit");

        int option = Console.Readline();

        switch (option)
        {
            case 1:
                PurchaseAppliance();
                break;

            case 2:
                FindAppliancesByBrand();
                break;

            case 3:
                DisplayRandomAppliances();
                break;

            case 4:
                DisplayRandomAppliances();
                break;

            case 5:
                break;

        }

        }       
